package Utility;

public class Constant {
	public static final boolean isClick=true;
	public static final boolean isNotClick=false;
	public static final String USERNAME="root";
	public static final String PASSWORD="0000";
	public static final String URL ="jdbc:mysql://localhost:3306/imagesearch";
}

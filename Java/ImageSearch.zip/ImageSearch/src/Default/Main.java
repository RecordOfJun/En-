package Default;
import Controller.Search;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Search a=new Search();
		a.LoadFrame();
		
	}

}
